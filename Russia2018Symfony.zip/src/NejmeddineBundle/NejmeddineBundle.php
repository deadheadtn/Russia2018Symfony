<?php

namespace NejmeddineBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class NejmeddineBundle extends Bundle
{
}
