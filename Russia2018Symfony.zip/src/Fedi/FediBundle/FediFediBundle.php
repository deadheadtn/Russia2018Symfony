<?php

namespace Fedi\FediBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class FediFediBundle extends Bundle
{
}
