<?php

namespace Fedi\FediBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class reservationHControllerTest extends WebTestCase
{
}
