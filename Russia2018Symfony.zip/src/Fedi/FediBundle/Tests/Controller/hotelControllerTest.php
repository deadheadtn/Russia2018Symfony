<?php

namespace Fedi\FediBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class hotelControllerTest extends WebTestCase
{
}
