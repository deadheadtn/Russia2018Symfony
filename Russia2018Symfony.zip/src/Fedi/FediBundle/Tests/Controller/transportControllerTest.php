<?php

namespace Fedi\FediBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class transportControllerTest extends WebTestCase
{
}
