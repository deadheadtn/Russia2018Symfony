<?php

namespace RUSSIA2\PIBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class RUSSIA2PIBundle extends Bundle
{
}
