<?php

namespace RUSSIA\PIBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class RUSSIAPIBundle extends Bundle
{
}
