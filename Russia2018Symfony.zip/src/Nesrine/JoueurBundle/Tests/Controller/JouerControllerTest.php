<?php

namespace Nesrine\JoueurBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class JouerControllerTest extends WebTestCase
{
}
