<?php

namespace Nesrine\JoueurBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class NesrineJoueurBundle extends Bundle
{
}
