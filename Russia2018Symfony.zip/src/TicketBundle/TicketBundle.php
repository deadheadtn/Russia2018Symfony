<?php

namespace TicketBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class TicketBundle extends Bundle
{
}
